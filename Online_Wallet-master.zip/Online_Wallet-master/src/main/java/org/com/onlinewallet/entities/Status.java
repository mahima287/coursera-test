package org.com.onlinewallet.entities;



public enum Status {
	
		ACTIVE, INACTIVE;
	
}

