package  org.com.onlinewallet;




import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class OnlineWalletApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineWalletApplication.class, args);


}
}
